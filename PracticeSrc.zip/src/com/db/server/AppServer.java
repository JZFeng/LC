package com.db.server;

/*�?凌 QQ:3312883*/
import java.io.*;
import java.net.*;
import java.util.zip.GZIPInputStream;

import com.db.protocol.DataUtil;
import com.db.protocol.TxNode;
import com.db.server.action.ActionHandlerManager;

public class AppServer extends Thread
{
    // 声�??�?务器套接字
    ServerSocket serverSocket;

    public AppServer()
    {
        try
        // �?�获异常
        {
            serverSocket = new ServerSocket(55001);// �?始化 �?务器套接字 设置�?务器端�?�为 55001
        }
        catch (IOException e)
        {
            fail(e, "�?能�?�动�?务器");// 如果�?始化失败 报错 显示异常
        }
        System.out.println("�?务器�?�动 . . .");// �?务器�?始化�?功
        start();// �?�动线程
    }

    public static void fail(Exception e, String str)// 自定义异常
    {
        System.out.println(str + "." + e);
    }

    public void run()// �?�动线程开始
    {
        try
        // �?�获异常
        {
            while (true)// while里就开始监�?�客户端数�?�
            {
                Socket client = serverSocket.accept();// 获�?�客户端Socket 当有数�?�到达时 把数�?�装到client里
                System.out.println("DB-Test --> Get client ");
                /* Connection con = */new Connection(client);// 然�?� �?始化一个Connection (PS:因为AppServer类到这里就是循环了
                                                             // 所以我把�?�?�那段注释掉了没影�?:)
            }
        }
        catch (IOException e)// 如果监�?�有问题就 包报错
        {
            fail(e, "Not listening");
        }
    }

    public static void main(String args[])// 程�?入�?�
    {
        new AppServer();// �?始化 AppServer
    }
}

class Connection extends Thread
{
    // 声明一个客户端的套接字(PS:上�?�那个是�?务器套接字 这个是客户端的)和 一个输入�?和输出�?
    protected Socket netClient;// 客户端的Socket

//    protected ObjectInputStream fromClient;// 从客户端获得数�?�
//    protected PrintStream toClient;// �?��?数�?�到客户端
    
    private static final int RESPONSE_COMPRESSED            = 983276847;
    private static final int RESPONSE_STREAMING             = 983276845;
    private static final int RESPONSE_STREAMING_COMPRESSED  = 983276846;

    public Connection(Socket client)// 这里就是41行 那里�?始化Connection
    {
        netClient = client;// 把client赋值到netClient里
        this.start();// �?�动第二个线程
    }

    public void run()// �?�动第二个线程开始
    {
        try
        // �?�获异常
        {
            long start = System.currentTimeMillis();
            OutputStream os = null;
            InputStream is = null;
            os = new BufferedOutputStream(netClient.getOutputStream());
            is = new BufferedInputStream(netClient.getInputStream()); 
            byte[] requestBuff = null;
            TxNode requestNode = null;
            TxNode respNode = null;
            boolean isWarm = true;
            
            while(isWarm)
            {
                int len = 0;
                for (int i = 0; i < 4; i++)
                {
                    int b = is.read();
                    if (b == -1)
                    {
                        // Socket closed
                        //System.out.println("read - socket closed");
                        return;
                        //return null;
                    }
                    len += (b << (i * 8));  
                }
                
                try
                {
                    requestBuff = read(is,len);
                    long end = System.currentTimeMillis();
                    if(requestBuff != null)
                    {
                        System.out.println("request length >>>>: "+requestBuff.length);
                    }
                    
                    System.out.println("The write and read time is >>>>" + (end - start) + "(ms)" );
                    if (requestBuff != null)
                    {
                        requestNode = TxNode.fromByteArray(requestBuff, 0);
                        System.out.println("requestNode: " + requestNode.toString());
                        
                        respNode = new TxNode();
                        int status = ActionHandlerManager.getInstance().handleRequest(requestNode, respNode);
                        System.out.println("DB-Test --> handle request Status : " + status);
                        
                        boolean isWriteSucc = write(os, TxNode.toByteArray(respNode));
                        System.out.println("DB-Test --> Write ifSucc : " + isWriteSucc );
                    }
                }
                catch(Exception e)
                {
                    
                }
            }
            
        }
        catch (IOException e)// 如果上�?�的�?始化有问题 就关闭套接字
        {
            try
            {
                netClient.close();// 关闭套接字
            }
            catch (IOException el)
            {
                System.err.println("Unable to set up streams" + el);
                return;
            }
        }
        finally
        // finally是撒�?�?�忘了...
        {
            try
            {
                netClient.close();
            }
            catch (IOException e)
            {

            }
        }
    }
    
    static public byte[] read(InputStream is,int len) throws Exception
    {
        byte[] response = null;
        try
        {
            if (len == -1)
                 return null;
             byte[] totalBytes = new byte[(int)len];
             int nRet = readBytes(is, totalBytes, 0, (int)len);
             if(nRet == -1)
                 return null;
             int offset = 0;
             if((offset + 3) >= totalBytes.length)
                 return totalBytes;
             byte[] lenBuf = new byte[4];
             lenBuf[0] = totalBytes[offset];
             lenBuf[1] = totalBytes[offset + 1];
             lenBuf[2] = totalBytes[offset + 2];
             lenBuf[3] = totalBytes[offset + 3];
             int chunkRespCode = DataUtil.readInt(lenBuf, 0);
             boolean isCompressed = (chunkRespCode == RESPONSE_STREAMING_COMPRESSED || chunkRespCode == RESPONSE_COMPRESSED);
             if (chunkRespCode == RESPONSE_STREAMING || chunkRespCode == RESPONSE_STREAMING_COMPRESSED)
             {
                 TxNode root = null;
                 offset = 4;
                 while (offset < len)
                 {
                     
                     if((offset + 4) > totalBytes.length)
                         return null;
                     lenBuf = new byte[4];
                     lenBuf[0] = totalBytes[offset];
                     lenBuf[1] = totalBytes[offset + 1];
                     lenBuf[2] = totalBytes[offset + 2];
                     lenBuf[3] = totalBytes[offset + 3];
                     int buffLen = DataUtil.readInt(lenBuf, 0);
                     offset += 4;
                     if (buffLen <= 0) continue;
                     if((offset + buffLen) > totalBytes.length)
                         return null;
                     int uncompressedLen = 0;
                     if (isCompressed)
                     {
                         if((offset + 4) > totalBytes.length)
                             return null;
                         lenBuf = new byte[4];
                         lenBuf[0] = totalBytes[offset];
                         lenBuf[1] = totalBytes[offset + 1];
                         lenBuf[2] = totalBytes[offset + 2];
                         lenBuf[3] = totalBytes[offset + 3];
                         uncompressedLen = DataUtil.readInt(lenBuf, 0);
                         offset += 4;     
                     }
                     
                     byte[] data = new byte[buffLen];
                     System.arraycopy(totalBytes, offset, data, 0, buffLen);
                     offset += buffLen;
                     
                     if (isCompressed)
                     {
                         data = uncompress(data, uncompressedLen);
                     }
//                     if(response == null)
//                     {
//                         response = data;
//                     }else
//                     {
//                         byte[] oldTmp = response;
//                         response = new byte[oldTmp.length + data.length];
//                         System.arraycopy(oldTmp, 0, response, 0, oldTmp.length);
//                         System.arraycopy(data, 0, response, oldTmp.length,
//                                 data.length);                         
//                     }
                     if(root == null)
                     {
                         root = TxNode.fromByteArray(data, 0);    
                     }else
                     {
                         root.addChild(TxNode.fromByteArray(data, 0));
                     }
                     
//                     
//                     Thread.yield();// yield after a big chunk
//                     if (job != null && job.callback != null && !job.isCancelled())
//                     {
//                         byte percent = (byte) (offset * 100 / len);
//                         job.callback.updateTransactionStatus(Networking.RECEIVING, percent);
//                     }
                 }
//                 if (job != null && job.callback != null && !job.isCancelled())
//                 {
//                     job.callback.updateTransactionStatus(Networking.RECEIVING, (byte) 100);
//                 }
                 response = TxNode.toByteArray(root);
             }
             else //only for map tile and traffic tile action process
             {
                 if (isCompressed)
                 {
                     offset = 4;
                     if((offset + 4) > totalBytes.length)
                         return null;
                     lenBuf = new byte[4];
                     lenBuf[0] = totalBytes[offset];
                     lenBuf[1] = totalBytes[offset + 1];
                     lenBuf[2] = totalBytes[offset + 2];
                     lenBuf[3] = totalBytes[offset + 3];
                     offset += 4;
                     int uncompressedLen = DataUtil.readInt(lenBuf, 0);
                     int compressedLen = len - offset;
                     
                     byte[] compressData = new byte[compressedLen];
                     System.arraycopy(totalBytes, offset, compressData, 0, compressedLen);
                     
                     byte[] data = uncompress(compressData, uncompressedLen);
                     response = data;
                 }else
                 {
                     response = totalBytes;
                 }
//                 if (job != null && job.callback != null && !job.isCancelled())
//                 {
//                     job.callback.updateTransactionStatus(Networking.RECEIVING, (byte) 100);
//                     
//                 }
             }
            System.out.println("--------> read - exit");
            return response;
        }
        catch (Exception e)
        {
            System.out.println("SocketClient::read: "+e.getMessage());
            return null;
        }
    }
    
    private static int readBytes(InputStream is, byte[] buff, int offset, int len) throws Exception
    {
        int bytesRead = 0;
        while (bytesRead < len)
        {
            int count = is.read(buff, offset, len - bytesRead);
            
//          System.out.println("RequestJob::readBytes: "+count);
//          trace.trace("comm, read: "+count, Comm.TRACE_FILTER);
            
            if (count < 0) break;
            bytesRead += count;
            offset += count;
            

        }
        return bytesRead;
    }
    private static byte[] uncompress(byte[] compressData, int uncompressedLen) throws Exception
    {
        byte[] uncompressData = new byte[uncompressedLen];
        ByteArrayInputStream bais = new ByteArrayInputStream(compressData);
        GZIPInputStream gis = new GZIPInputStream(bais);
        
        int offset = 0;
        while (offset < uncompressedLen)
        {
            int l = gis.read(uncompressData, offset, uncompressedLen - offset);
            if (l < 0) break;
            offset += l;
            
//          System.out.println("l: "+l+", offset: "+offset);
        }
        gis.close();
        bais.close();

//      System.out.println("uncompress: done");
        return uncompressData;
    }
    
    static public boolean write(OutputStream os, byte[] buff)
    {
        try
        {
//            if (job != null && job.callback != null && !job.isCancelled())
//            {
//                job.callback.updateTransactionStatus(Networking.SENDING, 0);
//            }

            int x = buff.length;
            for (int i = 0; i < 4; i++)
            {
                int b = x & 0xFF;
                os.write(b);
                x >>= 8;
            }

            os.write(buff);

            os.flush();

            return true;
        }
        catch (Exception e)
        {
            return false;
        }
    }
}