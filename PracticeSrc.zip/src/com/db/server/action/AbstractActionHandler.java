package com.db.server.action;

import com.db.protocol.TxNode;

public class AbstractActionHandler implements IActionHandler
{
    public int handleAction(TxNode requestNode, TxNode responseNode)
    {
        if(!checkNode(requestNode))
            return ActionHandlerManager.FAILED;
        
        return ActionHandlerManager.SUCCESS;
    }

    protected boolean checkNode(TxNode requestNode)
    {
        if(requestNode == null)
            return false;
        
        return true;
    }

    
}
