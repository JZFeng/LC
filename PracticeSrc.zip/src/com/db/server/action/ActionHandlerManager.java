package com.db.server.action;

import com.db.protocol.TxNode;

public class ActionHandlerManager
{
    final static public byte SUCCESS                    = 64;
    final static public byte FAILED                     = 65;
    final static public byte TOO_MANY_MATCHES           = 66;
    final static public byte STATIC_ROUTE               = 68;
    final static public byte RTS_FAILED                 = 69;
    final static public byte INIT                       = 70;
    final static public byte ON_TRACK                   = 71;
    final static public byte FOUND_YOU_INTERACTIVE      = 72;
    final static public byte MATCH_LIST                 = 73;
    final static public byte NO_MATCHES                 = 74;
    final static public byte ROUTE_CHUNK                = 75;
    final static public byte ZIP_VALID                  = 76;
    final static public byte ZIP_NON_VALID              = 77;
    final static public byte NO_ROUTE_YET               = 80;
    final static public byte CATEGORY_UPDATED           = 81;
    final static public byte CLIENT_VERSION             = 82;
    final static public byte USER_PREFS                 = 83;
    final static public byte CLIENT_IP                  = 84;
    final static public byte RULES_VERSION              = 85;
    final static public byte USER_INFO                  = 86;
    final static public byte CLIENT_INFO                = 87;
    final static public byte SERVER_MSG                 = 88;   
    final static public byte NO_CHANGED                 = 89;
    final static public byte WARM_DATA                  = 90;
    
    final static public int ACT_SEND_REQUEST            = 610;
    
    private ReportHandler reportHandler;
    
    private static class ActionHandlerManagerInstance
    {
        private static ActionHandlerManager manger = new ActionHandlerManager();
    }
    
    public static ActionHandlerManager getInstance()
    {
        return ActionHandlerManagerInstance.manger;
    }
    
    private IActionHandler getActionHandle(int action)
    {
        switch(action)
        {
            case ACT_SEND_REQUEST:
            {
                if(reportHandler == null)
                {
                    reportHandler = new ReportHandler();
                }
                
                return reportHandler;
            }
        }
        
        return null;
    }
    
    public int handleRequest(TxNode requestNode, TxNode responseNode)
    {
        int status = checkRequestNode(requestNode);
        
        if(status == FAILED || status == WARM_DATA)
        {
            if( responseNode == null )
                responseNode = new TxNode();
            
            responseNode.addValue(status);
            return status;
        }
        
        TxNode actionNode = requestNode.childAt(0);
        int action = (int)actionNode.valueAt(0);
        System.out.println("DB-Test --> Action : " + action);
        
        IActionHandler actionHandler = this.getActionHandle(action);
        if(actionHandler == null)
        {
            return FAILED;
        }
        else
        {
            return actionHandler.handleAction(actionNode, responseNode);
        }
    }

    private int checkRequestNode(TxNode requestNode)
    {
        if(requestNode == null)
        {
            return FAILED;
        }
        else if(requestNode.getValuesCount() > 0 && requestNode.valueAt(0) == 110496)
        {
            return WARM_DATA;
        }
        else if(requestNode.childrenSize() == 0)
        {
            return FAILED;
        }
        
        return SUCCESS;
    }
    
}
