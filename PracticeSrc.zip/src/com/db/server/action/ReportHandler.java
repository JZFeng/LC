package com.db.server.action;

import java.io.BufferedOutputStream;
import java.io.FileOutputStream;
import com.db.protocol.TxNode;

public class ReportHandler extends AbstractActionHandler
{
    public int handleAction(TxNode requestNode, TxNode responseNode)
    {
        int status = super.handleAction(requestNode, responseNode);
        if (status == ActionHandlerManager.SUCCESS)
        {
            TxNode reportNode = requestNode.childAt(0);

            String address = reportNode.msgAt(0);
            String description = reportNode.msgAt(1);
            String importance = reportNode.msgAt(2);
            System.out.println("DB-Test --> address: " + address + " , description : "
                    + description + " , importance : " + importance);
            
            byte[] imageData = reportNode.getBinData();
            
            try
            {
                BufferedOutputStream out = new BufferedOutputStream(new FileOutputStream("a.bmp"));
                out.write(imageData);
                out.close();
            }catch(Exception e )
            {
                
            }
        }
        else
        {
            return status;
        }

        return ActionHandlerManager.SUCCESS;
    }
}
