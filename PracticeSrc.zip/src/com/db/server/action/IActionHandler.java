package com.db.server.action;

import com.db.protocol.TxNode;

public interface IActionHandler
{
    public int handleAction(TxNode requestNode, TxNode responseNode);
}
