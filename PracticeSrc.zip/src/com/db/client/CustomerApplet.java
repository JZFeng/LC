package com.db.client;

/*�?凌 QQ:3312883*/
import javax.swing.*;

import com.db.protocol.Customer;
import com.db.protocol.DataUtil;
import com.db.protocol.TxNode;

import java.awt.*;
import java.awt.event.*;
import java.net.*;
import java.util.zip.GZIPInputStream;
import java.io.*;

public class CustomerApplet extends JApplet
{
    // 声明 �?��?� 标签 按钮....
    JPanel panelObject;

    JLabel labelCustName;

    JLabel labelCustPassword;

    JTextField textCustName;

    JPasswordField textCustPassword;

    JButton buttonLogin;

    GridBagLayout gl;

    GridBagConstraints gbc;
    
    static private int          SOCKET_LIFE_TIME    = 120000;
    
    private static final int RESPONSE_COMPRESSED            = 983276847;
    private static final int RESPONSE_STREAMING             = 983276845;
    private static final int RESPONSE_STREAMING_COMPRESSED  = 983276846;

    public void init()// 程�?入�?�
    {
        // �?始化 布局 �?��?
        gl = new GridBagLayout();// �?始化格�?布局 gl
        gbc = new GridBagConstraints();// �?始化格�?约�?�
        panelObject = (JPanel) getContentPane();// 设置主�?��?�
        panelObject.setLayout(gl);// 在主�?��?�里设置一个格�?布局 gl

        // �?始化 控件
        labelCustName = new JLabel("Customer Login Name");
        labelCustPassword = new JLabel("Password");
        textCustName = new JTextField(15);
        textCustPassword = new JPasswordField(15);
        buttonLogin = new JButton("Login");

        // 添加控件到�?��?�上
        gbc.anchor = GridBagConstraints.NORTHWEST;
        gbc.gridx = 1;
        gbc.gridy = 5;
        gl.setConstraints(labelCustName, gbc);
        panelObject.add(labelCustName);

        gbc.anchor = GridBagConstraints.NORTHWEST;
        gbc.gridx = 4;
        gbc.gridy = 5;
        gl.setConstraints(textCustName, gbc);
        panelObject.add(textCustName);

        gbc.anchor = GridBagConstraints.NORTHWEST;
        gbc.gridx = 1;
        gbc.gridy = 9;
        gl.setConstraints(labelCustPassword, gbc);
        panelObject.add(labelCustPassword);

        gbc.anchor = GridBagConstraints.NORTHWEST;
        gbc.gridx = 4;
        gbc.gridy = 9;
        gl.setConstraints(textCustPassword, gbc);
        panelObject.add(textCustPassword);

        gbc.anchor = GridBagConstraints.NORTHWEST;
        gbc.gridx = 2;
        gbc.gridy = 13;
        gl.setConstraints(buttonLogin, gbc);// 格�?布局gl设置约�?� 把buttonLogin加入约�?�
        panelObject.add(buttonLogin);

        LoginAction loginrequest = new LoginAction();// �?始化一个登陆按钮监�?�类 为loginrequest
        buttonLogin.addActionListener(loginrequest);// 给登陆按钮(buttonLogin)加上"登陆按钮监�?�类" 让他有事件功能
    }

    class LoginAction implements ActionListener// 登陆按钮监�?�类
    {
        public void actionPerformed(ActionEvent evt)// 当�?�生事件从这里开始
        {
            Object obj = evt.getSource();// �?�出事件内容
            if (obj == buttonLogin)// 判断事件内容
            {

//                Customer data = new Customer();// �?始化一个Customer类
//                data.custName = textCustName.getText();// �?�JTextField的内容也就是用户�?? 赋值到data.custName上
//                data.custPassword = new String(textCustPassword.getPassword());// 基本�?�上 这次是�?�的密�? 赋值到data.custPassword
                TxNode txNode = new TxNode();
                txNode.addMsg("Test");
                txNode.addMsg("TT");
                txNode.addValue(1);
                txNode.addValue(2);
                txNode.addValue(2);
                
                TxNode txNode1 = new TxNode();
                txNode1.addMsg("Test");
                txNode1.addMsg("TT");
                txNode1.addValue(1);
                txNode1.addValue(2);
                txNode1.addValue(2);
                
                txNode.addChild(txNode1);
                
                try
                // �?�获异常
                {
//                    Socket toServer;// 声明一个套接字用�?�连接�?务器
//                    toServer = new Socket("127.0.0.1", 1001);// �?始化toServer 开始连接�?务器
//                    ObjectOutputStream streamToServer = new ObjectOutputStream(toServer
//                            .getOutputStream());// �?始化一个输出�?用�?��?��?务器的IP 然�?�把 IP放入一个 �?�?始化的输出�?streamToServer 这个输出�?用�?� �?��?务器�?��?数�?�
//                    //streamToServer.writeObject((Customer) data);// �?��?数�?�到�?务器(SP "(Customer)data"这也是个数�?�转�?�
//                                                                // 到data转�?�到Customer类型)
//                    
//                    streamToServer.write(TxNode.toByteArray(txNode));
//
//                    // 下�?�这段就是监�?�了
//                    BufferedReader fromServer = new BufferedReader(new InputStreamReader(
//                            toServer.getInputStream()));// 这�?�看�?�这么长其实很简�?� 就是把�?务器返回的数�?� 放到fromServer里
//                    String status = fromServer.readLine();// 然�?�读出fromServer里的数�?� 到一个字符类型status
//                    getAppletContext().showStatus(status);// 在把status显示到 Applet里
//                    streamToServer.close();// 关闭输出�?
//                    fromServer.close();// 关闭BufferedReader //正常情况下 程�?到这里就终止了
                    
                    TxNode respNode = null;

                    byte[] buff = TxNode.toByteArray(txNode);
                    Socket sc = null;
                    String HOST_IP = "127.0.0.1";
                    int port = 55001;
                    OutputStream os = null;
                    InputStream is = null;
                    sc = new Socket(HOST_IP, port);
                    sc.setSoTimeout(SOCKET_LIFE_TIME);
                    os = new BufferedOutputStream(sc.getOutputStream());
                    is = new BufferedInputStream(sc.getInputStream());            
                    System.out.println("open is to: " + port);
                    System.out.println("Host IP: " + HOST_IP);
                    boolean isSuccess = true;
                    byte[] replyBuff = null;
                           
                    long start = System.currentTimeMillis();
                    isSuccess = write(os, buff);
                    
                    System.out.println("isSuccess: "+isSuccess);
                    if (isSuccess)
                    {
                        int len = 0;
                        for (int i = 0; i < 4; i++)
                        {
                            int b = is.read();
                            if (b == -1)
                            {
                                // Socket closed
                                //System.out.println("read - socket closed");
                                return;
                                //return null;
                            }
                            len += (b << (i * 8));  
                        }
                        try
                        {
                            replyBuff = read(is,len);
                            long end = System.currentTimeMillis();
                            if(replyBuff != null)
                            {
                                System.out.println("replyBuff length >>>>: "+replyBuff.length);
                            }
                            System.out.println("The write and read time is >>>>" + (end - start) + "(ms)" );
                            if (replyBuff != null)
                            {
                                respNode = TxNode.fromByteArray(replyBuff, 0);
                                System.out.println("respNode: " + respNode.toString());
                            }
                        }catch(Exception e)
                        {
                            
                        }
                    }
                

                }
                catch (InvalidClassException e)
                {
                    showStatus("The Customer class is invalid" + e);
                }
                catch (NotSerializableException e)
                {
                    showStatus("The object is not serializable" + e);
                }
                catch (IOException e)
                {
                    // showStatus("Cannot write to the server" + e);
                    showStatus("连接�?务器失败�?");
                }
            }
        }
    }
    
    public static boolean write(OutputStream os, byte[] buff)
    {
        if(buff == null)
        {
            return false;
        }
        try
        {
            int x = buff.length;
            for (int i = 0; i < 4; i++)
            {
                int b = x & 0xFF;
                os.write(b);
                x >>= 8;
            }
            //int b = 0x01;
            //os.write(b);

            os.write(buff);
            os.flush();
            //logger.debug("------------------------TxNode flush ok-----------------------");
            return true;
        } catch (Exception e)
        {
            System.out.println("SockeUtil::write:" + e.getMessage());
            return false;
        }
    }
    
    static public byte[] read(InputStream is,int len) throws Exception
    {
        byte[] response = null;
        try
        {
            if (len == -1)
                 return null;
             byte[] totalBytes = new byte[(int)len];
             int nRet = readBytes(is, totalBytes, 0, (int)len);
             if(nRet == -1)
                 return null;
             int offset = 0;
             if((offset + 3) >= totalBytes.length)
                 return totalBytes;
             byte[] lenBuf = new byte[4];
             lenBuf[0] = totalBytes[offset];
             lenBuf[1] = totalBytes[offset + 1];
             lenBuf[2] = totalBytes[offset + 2];
             lenBuf[3] = totalBytes[offset + 3];
             int chunkRespCode = DataUtil.readInt(lenBuf, 0);
             boolean isCompressed = (chunkRespCode == RESPONSE_STREAMING_COMPRESSED || chunkRespCode == RESPONSE_COMPRESSED);
             if (chunkRespCode == RESPONSE_STREAMING || chunkRespCode == RESPONSE_STREAMING_COMPRESSED)
             {
                 TxNode root = null;
                 offset = 4;
                 while (offset < len)
                 {
                     
                     if((offset + 4) > totalBytes.length)
                         return null;
                     lenBuf = new byte[4];
                     lenBuf[0] = totalBytes[offset];
                     lenBuf[1] = totalBytes[offset + 1];
                     lenBuf[2] = totalBytes[offset + 2];
                     lenBuf[3] = totalBytes[offset + 3];
                     int buffLen = DataUtil.readInt(lenBuf, 0);
                     offset += 4;
                     if (buffLen <= 0) continue;
                     if((offset + buffLen) > totalBytes.length)
                         return null;
                     int uncompressedLen = 0;
                     if (isCompressed)
                     {
                         if((offset + 4) > totalBytes.length)
                             return null;
                         lenBuf = new byte[4];
                         lenBuf[0] = totalBytes[offset];
                         lenBuf[1] = totalBytes[offset + 1];
                         lenBuf[2] = totalBytes[offset + 2];
                         lenBuf[3] = totalBytes[offset + 3];
                         uncompressedLen = DataUtil.readInt(lenBuf, 0);
                         offset += 4;     
                     }
                     
                     byte[] data = new byte[buffLen];
                     System.arraycopy(totalBytes, offset, data, 0, buffLen);
                     offset += buffLen;
                     
                     if (isCompressed)
                     {
                         data = uncompress(data, uncompressedLen);
                     }
//                     if(response == null)
//                     {
//                         response = data;
//                     }else
//                     {
//                         byte[] oldTmp = response;
//                         response = new byte[oldTmp.length + data.length];
//                         System.arraycopy(oldTmp, 0, response, 0, oldTmp.length);
//                         System.arraycopy(data, 0, response, oldTmp.length,
//                                 data.length);                         
//                     }
                     if(root == null)
                     {
                         root = TxNode.fromByteArray(data, 0);    
                     }else
                     {
                         root.addChild(TxNode.fromByteArray(data, 0));
                     }
                     
//                     
//                     Thread.yield();// yield after a big chunk
//                     if (job != null && job.callback != null && !job.isCancelled())
//                     {
//                         byte percent = (byte) (offset * 100 / len);
//                         job.callback.updateTransactionStatus(Networking.RECEIVING, percent);
//                     }
                 }
//                 if (job != null && job.callback != null && !job.isCancelled())
//                 {
//                     job.callback.updateTransactionStatus(Networking.RECEIVING, (byte) 100);
//                 }
                 response = TxNode.toByteArray(root);
             }
             else //only for map tile and traffic tile action process
             {
                 if (isCompressed)
                 {
                     offset = 4;
                     if((offset + 4) > totalBytes.length)
                         return null;
                     lenBuf = new byte[4];
                     lenBuf[0] = totalBytes[offset];
                     lenBuf[1] = totalBytes[offset + 1];
                     lenBuf[2] = totalBytes[offset + 2];
                     lenBuf[3] = totalBytes[offset + 3];
                     offset += 4;
                     int uncompressedLen = DataUtil.readInt(lenBuf, 0);
                     int compressedLen = len - offset;
                     
                     byte[] compressData = new byte[compressedLen];
                     System.arraycopy(totalBytes, offset, compressData, 0, compressedLen);
                     
                     byte[] data = uncompress(compressData, uncompressedLen);
                     response = data;
                 }else
                 {
                     response = totalBytes;
                 }
//                 if (job != null && job.callback != null && !job.isCancelled())
//                 {
//                     job.callback.updateTransactionStatus(Networking.RECEIVING, (byte) 100);
//                     
//                 }
             }
            System.out.println("--------> read - exit");
            return response;
        }
        catch (Exception e)
        {
            System.out.println("SocketClient::read: "+e.getMessage());
            return null;
        }
    }
    
    private static int readBytes(InputStream is, byte[] buff, int offset, int len) throws Exception
    {
        int bytesRead = 0;
        while (bytesRead < len)
        {
            int count = is.read(buff, offset, len - bytesRead);
            
//          System.out.println("RequestJob::readBytes: "+count);
//          trace.trace("comm, read: "+count, Comm.TRACE_FILTER);
            
            if (count < 0) break;
            bytesRead += count;
            offset += count;
            

        }
        return bytesRead;
    }
    private static byte[] uncompress(byte[] compressData, int uncompressedLen) throws Exception
    {
        byte[] uncompressData = new byte[uncompressedLen];
        ByteArrayInputStream bais = new ByteArrayInputStream(compressData);
        GZIPInputStream gis = new GZIPInputStream(bais);
        
        int offset = 0;
        while (offset < uncompressedLen)
        {
            int l = gis.read(uncompressData, offset, uncompressedLen - offset);
            if (l < 0) break;
            offset += l;
            
//          System.out.println("l: "+l+", offset: "+offset);
        }
        gis.close();
        bais.close();

//      System.out.println("uncompress: done");
        return uncompressData;
    }
}

