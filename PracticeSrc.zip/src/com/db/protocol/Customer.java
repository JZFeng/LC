package com.db.protocol;

import java.io.Serializable;


//客户信�?�
public class Customer implements Serializable
{
    // 声�?? 用户�?? 密�?
    public String custName;

    public String custPassword;

}