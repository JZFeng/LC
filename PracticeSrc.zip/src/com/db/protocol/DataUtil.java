/*
 * (c) Copyright 2001 MyCorporation.
 * All Rights Reserved.
 */
package com.db.protocol;

/**
 * @version 	1.0
 * @author
 */
public class DataUtil
{

	public static final int FIX_BITS = 8;

	static final int SCALE	= 8192;
	static final int SHIFT	= 13;

	private static final int sinTable[] = { 0, 1143, 2287, 3429, 4571, 5711,
			6850, 7986, 9120, 10252, 11380, 12504, 13625, 14742, 15854, 16961,
			18064, 19160, 20251, 21336, 22414, 23486, 24550, 25606, 26655,
			27696, 28729, 29752, 30767, 31772, 32767, 33753, 34728, 35693,
			36647, 37589, 38521, 39440, 40347, 41243, 42125, 42995, 43852,
			44695, 45525, 46340, 47142, 47929, 48702, 49460, 50203, 50931,
			51643, 52339, 53019, 53683, 54331, 54963, 55577, 56175, 56755,
			57319, 57864, 58393, 58903, 59395, 59870, 60326, 60763, 61183,
			61583, 61965, 62328, 62672, 62997, 63302, 63589, 63856, 64103,
			64331, 64540, 64729, 64898, 65047, 65176, 65286, 65376, 65446,
			65496, 65526, 0x10000 };

	private static final int atanTable[] = { 0, 0, 256, 512, 768, 1024, 1280,
			1536, 1792, 2048, 2048, 2304, 2560, 2816, 3072, 3328, 3584, 3584,
			3840, 4096, 4352, 4608, 4608, 4864, 5120, 5376, 5632, 5632, 5888,
			6144, 6400, 6400, 6656, 6912, 6912, 7168, 7424, 7680, 7680, 7936,
			8192, 8192, 8448, 8448, 8704, 8960, 8960, 9216, 9216, 9472, 9472,
			9728, 9984, 9984, 10240, 10240, 10496, 10496, 10752, 10752, 11008,
			11008, 11264, 11264, 11264 };

	private static final int sqrtTable[] = { 0x40000000, 0x4001fff8, 0x4007ff80,
			0x4011fd79, 0x401ff804, 0x4031ec87, 0x4047d7ad, 0x4061b56a,
			0x407f80fe, 0x40a134f9, 0x40c6cb42, 0x40f03d1b, 0x411d8325,
			0x414e956c, 0x41836b64, 0x41bbfbfc, 0x41f83d9b, 0x4238262d,
			0x427bab2b, 0x42c2c19f, 0x430d5e30, 0x435b7529, 0x43acfa7f,
			0x4401e1db, 0x445a1ea3, 0x44b5a3fe, 0x451464df, 0x4576540c,
			0x45db6424, 0x464387a8, 0x46aeb0fe, 0x471cd27d, 0x478dde6e,
			0x4801c717, 0x48787ebb, 0x48f1f7a3, 0x496e2425, 0x49ecf6a2,
			0x4a6e6191, 0x4af25781, 0x4b78cb1a, 0x4c01af24, 0x4c8cf689,
			0x4d1a9459, 0x4daa7bca, 0x4e3ca03c, 0x4ed0f53c, 0x4f676e85,
			0x50000000, 0x509a9dc9, 0x51373c2e, 0x51d5cfaf, 0x52764d01,
			0x5318a90f, 0x53bcd8f8, 0x5462d210, 0x550a89e3, 0x55b3f633,
			0x565f0cf6, 0x570bc45b, 0x57ba12c3, 0x5869eec9, 0x591b4f3a,
			0x59ce2b18, 0x5a82799a, 0x5a82799a };


	/*
	 * i, j are left shifted by 16
	 */
	static final int mul(int i, int j)
	{
		return (int) ((long) i * (long) j + 32768L >> 16);
	}

	/*
	 * result is left shifted by 16
	 */
	static final int div(int i, int j)
	{
		return (int) (((long) i << 16) / (long) j);
	}

	/**
	 * @param dx
	 * @param dy
	 * @return   sqrt(dx*dx + dy*dy)
	 */
	public static final int distance(int dx, int dy)
	{
		int k = Math.abs(dx);
		int l = Math.abs(dy);
		if (k > l)
		{
			int m = k;
			k = l;
			l = m;
		}
		if (l == 0)
		{
			return 0;
		} else
		{
			int m = div(k, l);
			int n = m >> 10;
			int d = (m & 0x3ff) << 6;
			m = mul(0x10000 - d, sqrtTable[n]) + mul(d, sqrtTable[n + 1]);
			m >>= 14;
			return mul(l, m);
		}
	}

	/*
	 * angle should be left shifted by 8
	 * result is left shifted by 16
	 */
	public static int sin(int angle)
	{
		boolean flag = false;
		if (angle < 0)
		{
			angle = -angle;
			flag = !flag;
		}

		if (angle > 0x16800)
		{
			for (; angle > 0x16800; angle -= 0x16800)
				;
		}

		if (angle > 46080)
		{
			angle = 0x16800 - angle;
			flag = !flag;
		}

		if (angle > 23040)
		{
			angle = 46080 - angle;
		}

		int j = sinTable[angle >> 8];
		return flag ? -j : j;
	}

	/*
	 * i should be left shifted by 8
	 * result is left shifted by 16
	 */
	public static int cos(int i)
	{
		return sin(23040 - i);
	}

	/*
	 * i should be left shifted by 8
	 * result is left shifted by 16
	 */
	public static int tan(int i)
	{
		return div(sin(i), cos(i));
	}

	public static int atan2(int delY, int delX)
	{
		int k;
		if (delX > 0 && delY >= 0)
			k = 0;

		else if (delX <= 0 && delY > 0)
		{
			int l = -delX;
			delX = delY;
			delY = l;
			k = 23040;
		} else if (delX < 0 && delY <= 0)
		{
			delX = -delX;
			delY = -delY;
			k = 46080;
		} else if (delX >= 0 && delY < 0)
		{
			int i1 = delX;
			delX = -delY;
			delY = i1;
			k = 0x10e00;
		} else
		{
			return 0;
		}
		if (delX >= delY)
		{
			int j1 = div(delY, delX) >> 10;
			k += atanTable[j1];
		} else
		{
			int k1 = div(delX, delY) >> 10;
			k += 23040 - atanTable[k1];
		}
		return k;
	}


	/**
	 * calculate X * cosine ( Y ) using the approximation table
	 * @param x - X value (SCALE), shifted left by 13
	 * @param y - Y value (angle)
	 * @return X * cosine ( Y ) , shifted left by 13
	 */
	public static long xCosY(long x, int y)
	{
		x *= cos(y << FIX_BITS);
		return (x+32767) >> (FIX_BITS*2);
	}

	/**
	 * calculate X * sin ( Y ) = X * cos ( Y + 270 )
	 * x should be shifted left by 13 and result is shifted left by 13
	 */
	public static long xSinY(long x, int y)
	{
		return xCosY(x, y + 270);
	}

    /**
     * calculate the root sum square ( RSS )
     */
    public static long rss(long a, long b)
    {
        long absa = Math.abs(a);
        long absb = Math.abs(b);
        long sumq;
        long root;

        sumq = a * a + b * b;

        root = (absa > absb) ? absb / 2 + absa : absa / 2 + absb;

        if (root == 0)
        {
            return 0;
        }

        for (int i = 0; i < 4; i++)
        {
            root += sumq / root;
            root = root >> 1;
        }

        return root;
    }

	/**
	 * calculate the root sum square ( RSS )
	 */
	public static int rss(int a, int b)
	{
		return distance(a, b);
	}

	/* brng(here, there)
	 * will not work properly around 0 lat or 0 lon
	 * return the bearing angle from point "here" to point "there" in
	 * degrees from 0-359 with error < 3 degrees
	 */
	public static int bearing(int hereLat, int hereLon, int thereLat, int thereLon)
	{
		// northing
		int dn = thereLat - hereLat;
		// convert avg lat in DM5 to degrees
		int avgLatDeg = (int) ((21 * (thereLat + hereLat)) >> 22);
		// easting
		int de = (int)xCosY(thereLon - hereLon, avgLatDeg);

		return bearing(dn, de);
	}
	
	/**
	 *  return clockwise angle for the line heading
	 */
	public static int calcLineHeading(int xFrom, int yFrom, int xTo, int yTo)
	{
		int d1 = (xTo - xFrom) << FIX_BITS;
		int d2 = (yTo - yFrom) << FIX_BITS;
	
		int angle = - (DataUtil.atan2(d1, d2)>> FIX_BITS);
		while(angle < 0) angle += 360;
		while (angle >= 360) angle -= 360;
		
		return angle;
	}	

	public static int bearing(int dn, int de)
	{
		long radial = rss(dn, de); // radial distance
		// set up a binary search for angle
		int n = 0;
		int s = 180;
		int angle = (s + n) >> 1; // average angle
		while (n < s - 4) // convergence test
		{
			// tn is radial * cosine(angle)
			long tn = xCosY(radial, angle);
			// decide which end of the arc to replace with angle
			// depending on whether dn is greater or less than tn
			if (dn > tn)
				s = angle; //decrease the angle
			else
				n = angle; // increase the angle
			angle = (n + s) >> 1; // average of n and s
		} // use easting to determine if in east or west semicircle
		return (de > 0) ? angle : 360 - angle;
	}

	/**
	 * calculate the gps distance between two points
	 * @param 	lat1			[in]	dm5
	 * @param	lon1			[in]	dm5
	 * @param	lat2			[in]	dm5
	 * @param	lon2			[in]	dm5
	 * @param	cosLat			[in]	shifted left by 13
	 * @return	gps distance (dm5)
	 */
	public static int gpsDistance(int lat1, int lon1, int lat2, int lon2, int cosLat)
	{
	    int deltalat = lat1 - lat2;
	    int deltalon = lon1 - lon2;
	    return gpsDistance(deltalat, deltalon, cosLat);
	} // gpsDistance

	/**
	 * calculate the gps distance between two points
	 * @param 	deltaLat		[in]	dm5
	 * @param	deltaLon		[in]	dm5
	 * @param	cosLat			[in]	shifted left by 13
	 * @return	gps distance (dm5)
	 */
	public static int gpsDistance(int deltaLat, int deltaLon, int cosLat)
	{
//	    //if either deltalat or deltalon are too big, dont do rss:
//	    //it has a problem for large values.  just return MAX_INT
	    int distance;
//	    int bigVal = 20000;//about 20km
//	    if (deltaLat > bigVal || deltaLon > bigVal) distance = 65535;//MAX_INT
//		else
		distance = DataUtil.rss(
				deltaLat,
				(int)((long)(deltaLon) * cosLat) >> SHIFT);

	    //sanity check
	    if (distance == 0) distance = 1;
	    return distance;
	} // gpsDistance

	/**
	 * convert heading value into one of 8 sector values
	 * each sector subtends 45 degrees, offset by 22.5 degrees
	 * from [-22.5 to 22.5) maps to sector 0
	 */
	public static int headingToSector(int heading)
	{
		//double the heading, add 360+45, then mod 720 to put into
		//positive double circle, then divide by 90 to form octant index
		return (( 2 * heading + 45 ) % 720) / 90;
	}


	static public void sleep(long time)
	{
		try
		{
			Thread.sleep(time);
		}
		catch (Exception e)
		{
			//#if DEBUG
			//# e.printStackTrace();
			//#endif
		}
	}

	/** append a byte into byte array, checking for overflow */
	static public byte[] setByte(byte[] buff, byte b, int counter)
	{
		while (counter >= buff.length)
		{
			byte[] newBuff = new byte[2 * buff.length];
			for (int i = 0; i < buff.length; i++) newBuff[i] = buff[i];
			buff = newBuff;
		}

		buff[counter] = b;
		return buff;
	}

	public static byte[] intArrayToByteArray(int[] value)
	{
		if (value == null)
			return null;
		byte[] buff = new byte[value.length << 2];
		for (int i=0; i<value.length; i++)
		{
			writeInt(buff, value[i], i<<2);
		}
		return buff;
	}

	public static int[] byteArrayToIntArray(byte[] buff)
	{
		if (buff == null)
			return null;
		int[] value = new int[buff.length >> 2];
		for (int i=0; i<value.length; i++)
		{
			value[i] = readInt(buff, i<<2);
		}
		return value;
	}

	public static int read(byte[] buff, int offset, int number)
	{
		if (number == 1)
			return buff[offset];
		else if (number == 2)
			return readShort(buff, offset);
		else if (number == 3)
		{
			int mask = 0xFF;
			return (mask & buff[offset]) + ((mask & buff[offset+1]) << 8) + (((int)buff[offset+2]) << 16);
		}
		else if (number == 4)
			return readInt(buff, offset);
		else
		{
			throw new RuntimeException("unsupported number "+number);
		}
	}

	public static int write(byte[] buff, int value, int offset)
	{
		if (value >= -128 && value <= 127)
		{
			buff[offset] = (byte)value;
			return 1;
		}
		else if (value >= -32768 && value <= 32767)
		{
			writeShort(buff, value, offset);
			return 2;
		}
		else if (value >= -8388608 && value <= 8388607)
		{
			buff[offset] = (byte) (value & 0xFF);
			value = value >> 8;
			buff[offset+1] = (byte) (value & 0xFF);
			value = value >> 8;
			buff[offset+2] = (byte) (value & 0xFF);
			return 3;
		}
		else
		{
			writeInt(buff, value, offset);
			return 4;
		}
	}

	/**
	 * convert byte array into int
	 * NOTE: cast to INT essential for sign propagation
	 */
	static public int readInt(byte[] buff, int offset)
	{
		int mask = 0xFF;
		return (mask & buff[offset]) + ((mask & buff[offset+1]) << 8) + ((mask & buff[offset+2]) << 16) + ((int) buff[offset+3] << 24);
	}

	/**
	 * write an int into a byte array
	 *
	 * @param num - the number to write
	 * @param offset - the offset into the array to write it to
	 */
	static public void writeInt(byte [] buff, int num, int offset)
	{
		buff[offset] = (byte) (num & 0xFF);
		num = num >> 8;
		buff[offset+1] = (byte) (num & 0xFF);
		num = num >> 8;
		buff[offset+2] = (byte) (num & 0xFF);
		num = num >> 8;
		buff[offset+3] = (byte) (num & 0xFF);
	}

	/**
	 * convert byte array into short (cast to int) value
	 * NOTE: cast to INT essential for sign propagation
	 */
	static public int readShort(byte[] buff, int offset)
	{
		int mask = 0xFF;
		return (mask & buff[offset]) + ((int) buff[offset+1] << 8);
	}

	/**
	 * write an int as SHORT into the byte array: only write 2 bytes.
	 * @param buff
	 * @param num
	 * @param offset
	 */
	static public void writeShort(byte [] buff, int num, int offset)
	{
		buff[offset] = (byte) (num & 0xFF);
		num = num >> 8;
		buff[offset+1] = (byte) (num & 0xFF);
	}

	/**
	 * calculate the projection of other position along reference position
	 */
	public static int project(int referenceLat,
						int referenceLon,
						int referenceDeltaR,
						int otherLat,
						int otherLon,
						int coslat)
	{
		//check for deltar = 0
		if (referenceDeltaR == 0)
			return 1;

		//coslat = SCALE (8192) * cosine ( lattitude )
		//so multiply non-cosine weighted terms by SCALE (8192) as well
		//RM: NOTE, lat needs to have SCALE ^ 2, while lon needs to have
		//coslat ^ 2, and reflengh needs to have SCALE * rss !!!!
		long dotprod = (long) referenceLat * SCALE * otherLat * SCALE +
						(long) coslat * referenceLon * coslat * otherLon;

		long reflength = (long) referenceDeltaR * SCALE * SCALE;

		long result = dotprod / reflength;
		return (int) result;
	}

	/**
	 * calculate the cross product of 2 shape points
	 */
	public static int cross(int referenceLat,
					int referenceLon,
					int referenceDeltaR,
					int otherLat,
					int otherLon,
					int coslat)
	{
		//check for deltar = 0
		if (referenceDeltaR == 0)
			return 1;

		long reflength = (long) referenceDeltaR * SCALE * SCALE;

		//return cross product of the 2 shape points
		return (int) (((long) referenceLat * otherLon - referenceLon * otherLat) *
				SCALE * coslat / reflength);
	}

	public static int getCosLat(int lat)
	{
		return (int) xCosY(SCALE, ( 21 * Math.abs(lat) ) >> 21);
	}

	public static long getLongForBytes(byte[] buff)
	{
	    long mask = 0xFF;
		long res = 0;

		for (int i = 0; i < 8; i++) {
			res += ((mask & buff[i]) << (i * 8));
		}
		return res;
	}

	public static byte[] getBytesForLong(long num)
	{
		byte[] buff = new byte[8];

		for (int i = 0; i < 8; i++) {
			buff[i] = (byte) (num & 0xFF);
			num = num >> 8;
		}

		return buff;
	}
	
	public static boolean isInBoundingBox(int x, int y, int xmin, int ymin, int xmax, int ymax)
	{
	    return (x>=xmin && x<=xmax) && (y>=ymin && y<=ymax);
	}
	
	/**
	 *  Judge if point(x0,y0) is at the left space of line (x1,y1) - (x,y)
	 * 
	 * @param x0
	 * @param y0
	 * @param x1
	 * @param y1
	 * @param x
	 * @param y
	 * 
	 * @return 0 :  if point(x0,y0) is on the line
	 *         1 :  if point(x0,y0) is at the left space of the line 
	 *        -1 :  if point(x0,y0) is NOT at the left space of the line  
	 */
	
	public static int isLeft(int x0, int y0 , int x1, int y1, int x, int y)
	{
	    int value = (x1 - x0) * (y - y0) - (x - x0) * (y1 - y0);
	    
		if  (value == 0)
		    return 0;
		else if (value > 0)
		    return 1;
		else
		    return -1;
	}

	 /**
	 *  judge if two lines are intersected
	 */
	public static boolean isIntersecting(int lon1, int lat1, int lon2,int lat2, 
	                                     int lon3, int lat3, int lon4, int lat4) 
	{
		lon2 = lon2 - lon1; 
		lat2 = lat2 - lat1;
		
		lon3 = lon3 - lon1;
		lat3 = lat3 - lat1;
		
		lon4 = lon4 - lon1;
		lat4 = lat4 - lat1; 
		
		lon1 = lat1 = 0;
		
		// if two lines intersect, the bouding rects of them should intersect.
		if (Math.min(lon1, lon2) > Math.max(lon3, lon4)
				|| Math.min(lon3, lon4) > Math.max(lon1, lon2)
				|| Math.min(lat1, lat2) > Math.max(lat3, lat4)
				|| Math.min(lat3, lat4) > Math.max(lat1, lat2))
		{
			return false;
		}
		
		if ( isLeft(lon1,lat1,lon3,lat3,lon4,lat4) *  isLeft(lon2,lat2,lon3,lat3,lon4,lat4) <=0  && 
		     isLeft(lon3,lat3,lon1,lat1,lon2,lat2) *  isLeft(lon4,lat4,lon1,lat1,lon2,lat2) <=0 )
	         return true;
		else 
		     return false;
	}
	
	//read value from buff started at offset[0], the value size is self-defined
	public static long readValue(byte[] buff, int[] offset)
	{
	    long value;
	    byte first = buff[offset[0]];
		if ((first & 1) == 0)
		{
			value = (first >> 1);
			offset[0] += 1;
		}
		else if ((first & 2) == 0)
		{
			value = read2(buff, offset[0], 2)>>2;
			offset[0] += 2;
		}
		else if ((first & 31) != 31) //last five bits are not all "1"
		{
			if ((first & 4) == 0)
			{
			    value = read2(buff, offset[0], 3)>>3;
				offset[0] += 3;
			}
			else if ((first & 8) == 0)
			{
			    value = read2(buff, offset[0], 4)>>4;
				offset[0] += 4;
			}
			else
			{
			    value = read2(buff, offset[0], 5)>>5;
				offset[0] += 5;
			}
		}
		else
		{
			if ((first & 32) == 0)
			{
			    value = read2(buff, offset[0], 6)>>6;
				offset[0] += 6;
			}
			else if ((first & 64) == 0)
			{
			    value = read2(buff, offset[0], 7)>>7;
				offset[0] += 7;
			}
			else
			{
			    value = read2(buff, offset[0]+1, 8);
				offset[0] += 9;
			}
		}
		
		return value;
	}
	
	//write value into buff started at offset, and also write the value size info
	public static int writeValue(byte[] buff, int offset, long value)
	{
	    if (value >= -64 && value <= 63) //2^6
	    {
	        buff[offset] = (byte)(value<<1);
	        return 1;
	    }
	    else if (value >= -8192 && value <= 8191) //2^13
	    {
	        write(buff, offset, 2, (value<<2) | 1);
	        return 2;
	    }
	    else if (value >= -17179869184L && value <= 17179869183L) //2^34
	    {
		    if (value >= -1048576 && value <= 1048575) //2^20
		    {
		        write(buff, offset, 3, (value<<3) | 3);
		        return 3;
		    }
		    else if (value >= -134217728 && value <= 134217727) //2^27
		    {
		        write(buff, offset, 4, (value<<4) | 7);
		        return 4;
		    }
		    else
		    {
		        write(buff, offset, 5, (value<<5) | 15);
		        return 5;
		    }
	    }
	    else
	    {
		    if (value >= -2199023255552L && value <= 2199023255551L) //2^41
		    {
		        write(buff, offset, 6, (value<<6) | 31);
		        return 6;
		    }
		    else if (value >= -281474976710656L && value <= 281474976710655L) //2^48
		    {
		        write(buff, offset, 7, (value<<7) | 63);
		        return 7;
		    }
		    else
		    {
		        buff[offset] = -1;
		        write(buff, offset+1, 8, value);
		        return 9;
		    }
	    }
	}
	
	//get byte size for specified value
	public static int getValueLength(long value)
	{
	    if (value >= -64 && value <= 63) //2^6
	    {
	        return 1;
	    }
	    else if (value >= -8192 && value <= 8191) //2^13
	    {
	        return 2;
	    }
	    else if (value >= -17179869184L && value <= 17179869183L) //2^34
	    {
		    if (value >= -1048576 && value <= 1048575) //2^20
		    {
		        return 3;
		    }
		    else if (value >= -134217728 && value <= 134217727) //2^27
		    {
		        return 4;
		    }
		    else
		    {
		        return 5;
		    }
	    }
	    else
	    {
		    if (value >= -2199023255552L && value <= 2199023255551L) //2^41
		    {
		        return 6;
		    }
		    else if (value >= -281474976710656L && value <= 281474976710655L) //2^48
		    {
		        return 7;
		    }
		    else
		    {
		        return 9;
		    }
	    }
	}
	
	//read eight bytes from buffer and convert it to long
	public static long readLong(byte[] buff, int offset)
	{
	    return read2(buff, offset, 8);
	}
	
	//write long into buff
	public static void writeLong(byte[] buff, int offset, long value)
	{
	    write(buff, offset, 8, value);
	}


	/**
	 * read bytes from buff and convert to long by 'count' 
	 * @param buff [in] 
	 * @param offset start index 
	 * @param count [in] the size of bytes for the value
	 * @return
	 */
	public static long read2(byte[] buff, int offset, int count)
	{
	    int mask = 0xFF;
	    long value = 0;
	    for (int i=0; i<count - 1; i++)
	    {
	        value += (mask & (long)buff[offset+i]) << (i * 8); 
	    }
	    value += (long)buff[offset+count-1] << ((count -1)*8);
	    return value;
	}
	
	//write bytes of 'count' into buff
	public static void write(byte[] buff, int offset, int count, long value)
	{
	    for (int i=0; i<count; i++)
	    {
	        buff[offset+i] = (byte)(value & 0xFF);
	        value >>= 8;
	    }
	}
	
	public static void quickAssign(int data[], int startIndex, int len,int value) 
	{
		data[startIndex] = value;

		int l;
		for (int i = 1; i < len; i = l) 
		{
			l = Math.min(i + i, len);
			System.arraycopy(data, startIndex, data, startIndex + i, l - i);
		}
	}

}
