package jz.CreateFakeTraffic;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashSet;
import java.util.Iterator;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class GenerateFakeTraffic
{

    public GenerateFakeTraffic()
    {
    }

    public static void main(String args[]) throws IOException
    {
        
        //find json file
        int i = 0;
        String jsonFileName = null;
        File f = new File(".");
        File[] files = f.listFiles();
        for(File file: files)
        {
            if(i<2)
            {
                if(file.getName().contains("json"))
                {
                    i++;
                    jsonFileName = file.getName().trim();
                }
            }
            else
            {
                System.out.println("More than one json files under corrent folder. Exiting...");
                System.exit(0);
            }
        }
        
        //get all unique traffic_ID from json file and store it into a hashSet.
        HashSet<String> trafficIDs = new HashSet<String>(); 
        File file = new File(jsonFileName);
        BufferedReader reader = new BufferedReader(new FileReader(file));
        String line = reader.readLine();
        
        String regEx = "(traffic_id\":\")(\\d{10,20})";
        Pattern p = Pattern.compile(regEx);
        Matcher m = p.matcher(line);
        while(m.find())
        {
            trafficIDs.add(m.group(2));
        }
        
        reader.close();

        
        //iterate hashSet and generate fake traffic flow info.
        File dest = new File("./fakeTrafficFlow.txt");
        BufferedWriter writer = new BufferedWriter(new FileWriter(dest));
        
        Iterator it=trafficIDs.iterator();
        while(it.hasNext())
        {
            String fakeTrafficFlow= getFakeFlowbyTrafficID((String) it.next());
            System.out.println(fakeTrafficFlow);
            writer.write(fakeTrafficFlow);
            writer.newLine();
        }
        
        writer.flush();
        writer.close();
 
    }

    //Sample Fake Traffic Flow: 2012-06-13T17:47:01,29:1,L:1033350111842004,0 miles,span:1033350111842004,.8,2 mph
    private static String getFakeFlowbyTrafficID(String trafficID)
    {
        Date d = new Date();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        SimpleDateFormat sdf1 = new SimpleDateFormat("kk:mm:ss");
        String str = sdf.format(d);
        str = (new StringBuilder(String.valueOf(str))).append("T").append(sdf1.format(d)).toString();
        String fakeTrafficFlow = (new StringBuilder(String.valueOf(str))).append(",").append("29:1,").append("L:" + trafficID).append(",0 miles,").append("span:").append(trafficID).append(",").append(".8,").append("5 mph").toString();
        return fakeTrafficFlow;
    }
    
    
}
