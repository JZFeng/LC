package jz.CreateFakeTraffic;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.Charset;
import java.text.Format.Field;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;
import java.util.SortedMap;

public class ReadTMC {

	public static void main(String[] args) throws IOException {
		

		SortedMap sm = Charset.availableCharsets();
		Set s = sm.keySet();
		Iterator it = s.iterator();
		while(it.hasNext())
		{
			System.out.println(it.next());
		}
		
		InputStreamReader is = new InputStreamReader(System.in); 
		char[] tmp = null ;
		int i = is.read();
		while(i > 0 && i != 13)
		{
			System.out.print((char)i);
			i = is.read();
		}

		int a = (int)('a');
		System.out.println(a);
		

/*		HashMap hm = storeTMCtoHashMap();
		HashSet hs = getTMCIDs();
		File ttl = new File("./ttl.txt");
		BufferedWriter bw = new BufferedWriter(new FileWriter(ttl));
		
		
		Iterator it = hs.iterator();
		while (it.hasNext()) {
			String tmc = (String) it.next();
			String tl = (String)hm.get(tmc);
			bw.write(tl);
			bw.newLine();
		}

		bw.flush();
		bw.close();*/
	}

	private static HashSet getTMCIDs() throws IOException {
		HashSet results = new HashSet();
		File tmc = new File("./test.txt");
		BufferedReader br = new BufferedReader(new FileReader(tmc));

		String line = br.readLine();
		
		while (line != null && line.length() > 0) {
			results.add(line);
			line = br.readLine();
		}

		br.close();

		return results;

	}

	private static HashMap storeTMCtoHashMap() throws FileNotFoundException,
			IOException {
		File o = new File("./TmcToTtlMap.txt");
		BufferedReader br = new BufferedReader(new FileReader(o));
		HashMap hm = new HashMap();
		String line = br.readLine();

		while (line != null && line.length() > 0) {
			String[] tmp = line.split(",");
			if (tmp != null && tmp.length > 1) {
				hm.put(tmp[0], tmp[1]);
			}

			line = br.readLine();
		}

		br.close();
		return hm;
	}

}
